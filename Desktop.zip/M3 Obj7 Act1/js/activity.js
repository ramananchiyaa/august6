var dragAndDropActivity = function(){
    var _this = this;

    this.init = function(){
        console.log("Init Function Called");

        _this.submitBtn = $('#submitBtn');
        _this.audioElem = $('#audioElem');
        _this.actCloseBtn = $('#closeBtn');
        _this.reset = $('#reset');

        _this.isCorrectlyDropped = false;
        _this.droppedItemsCount = 0;
        _this.correctDropCount = 0;
        _this.inCorrectDropCount = 0;
        _this.totalCount = 6;

        _this.getJsonData();
        _this.addEvents();
    }

    this.getJsonData = function(){
        $.ajax({
            url : "assets/data/data.json",
            type : "GET",
            cache : false,
            success : _this.loadDatasSuccess,
            error : _this.onLoadError
        });
    }

    this.loadDatasSuccess = function(jsondatas){
        _this.jsonDatas = jsondatas.data;
        console.log("Json Data Is",_this.jsonDatas);

        _this.audioElem.attr('src',_this.jsonDatas.audio.audioPath+_this.jsonDatas.audio.startingAudio);
        _this.audioElem[0].play();

        _this.loadDragDatas();
    }

    this.onLoadError = function(){
        console.log("Error on loading json data");
    }

    this.loadDragDatas = function(){
        console.log("load data function")

        for(let i=0; i<_this.jsonDatas.dragData.length; i++){
            $('#'+(i+1)).css({
                "background" : "url("+_this.jsonDatas.imagePath + _this.jsonDatas.dragData[i].bgImage+")",
                "background-size" : "100% 100%"
            })
            .attr('key',_this.jsonDatas.dragData[i].key);
            $("<span class='flag'></span>").appendTo('#'+(i+1));
        }

        for(let i=0; i<_this.jsonDatas.dropData.length; i++){
            $('#dropHolder'+(i+1)).attr('bay',_this.jsonDatas.dropData[i].bay);
        }
    }

    this.addEvents = function(){
        $('.dragItem').draggable({
            appendTo: "body",
            containment : $('body'),
            start: function(){
                _this.isCorrectlyDropped = false;
                $(this).css('transition' , '0s');
                _this.droppedItemsCount = 0;
            },
            drag: function(){
                _this.submitBtn.css("pointer-events","none");
                $(this).css('z-index',1);
            },
            stop: function(){
                _this.revert(this);
                $(this).css('z-index',0);
                if(_this.isCorrectlyDropped){
                    console.log('Valid Drop');	
                }else{
                    console.log('Invalid Drop');
                }
            }
        });

        $('.dropItemHolder').droppable({
            drop: function(event,ui){
                _this.isCorrectlyDropped = true;
                _this.curDragElement = $(ui.draggable);
                _this.curDroppedElment = $(this);
                _this.appendElement();
                _this.isAllItemsDropped();
            }
        });

       _this.submitBtn.off("click").on("click",_this.validation);
       _this.actCloseBtn.off("click").on("click",_this.closeActivity);
       _this.reset.off("click").on("click",_this.resetActivity);
    }

    this.appendElement = function(){
        $(_this.curDragElement).appendTo(_this.curDroppedElment[0]);
        _this.removeFirstChild();
    }

    this.removeFirstChild = function(){
        let childLength = _this.curDroppedElment.children().length;
        if(childLength == 2){
            let childern = _this.curDroppedElment.children(),
                removableElement = childern[0],
                removableElementId = $(removableElement).attr('id');

            $(removableElement).appendTo($('#dragHolder'+removableElementId));
        }
    }

    this.revert = function(curElem){
        $(curElem).css({
            "top" : "0",
            "left" : "0",
            "right" : "0",
            "bottom" : "0",
            "transition" : "0.5s"
        });
    }

    this.isAllItemsDropped = function(){

        for(let i=0; i<_this.jsonDatas.dropData.length; i++){
            _this.droppedItemsCount = _this.droppedItemsCount + $('#dropHolder'+(i+1)).children().length;
        }

        if(_this.droppedItemsCount == _this.totalCount){
            _this.submitBtn.css('pointer-events','auto');
        }
    }

    this.validation = function(){
        for(let i=0; i<_this.jsonDatas.dropData.length; i++){

            let currentbay =  $('#dropHolder'+(i+1)).attr('bay'),
                childrens = $('#dropHolder'+(i+1)).children(),
                currentkey = $(childrens[0]).attr('key'),
                itsChild = $(childrens[0]).children();

                if( currentbay == currentkey ){
                    $(itsChild[0]).css({
                        "background" : "url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.correct+") no-repeat",
                        "opacity" : "1",
						"background-size" : "100% 100%"
                    });

                    _this.correctDropCount++;
               }else{
                $(itsChild[0]).css({
                    "background" : "url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.incorrect+") no-repeat",
                    "opacity" : "1",
					"background-size" : "100% 100%"
                });

                _this.inCorrectDropCount++;
               }

               _this.playFeedBackAudio();
               

            //_this.submitBtn.hide();
        }
    }

    this.playFeedBackAudio = function(){
        if(_this.correctDropCount == _this.totalCount){
            _this.audioElem.attr('src',_this.jsonDatas.audio.audioPath+_this.jsonDatas.audio.correct);
            _this.audioElem[0].play();
        }else if(_this.correctDropCount == 5 || _this.correctDropCount == 4){
            _this.audioElem.attr('src',_this.jsonDatas.audio.audioPath+_this.jsonDatas.audio.almostCorrect);
            _this.audioElem[0].play();
        }else{
            _this.audioElem.attr('src',_this.jsonDatas.audio.audioPath+_this.jsonDatas.audio.incorrect);
            _this.audioElem[0].play();
        }
    }

    this.resetActivity = function(){
        for(let i=0; i<_this.jsonDatas.dragData.length; i++){
			$('#'+_this.jsonDatas.dragData[i].id).appendTo($('#dragHolder'+_this.jsonDatas.dragData[i].id));
        }

        $('.flag').css('opacity','0');
        $(_this.submitBtn).css('pointer-events','none');
        _this.correctDropCount = 0;
    }

    this.closeActivity = function(){
        console.log("Close this activity");
    }
}