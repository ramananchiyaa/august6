var Obj5Activity1 = function(){
    var _this = this;

    this.init = function(){
        console.log("Init Function Invoked");

        _this.actCloseBtn = $('#closeBtn');
        _this.audioElem = $('#audioElem');
        _this.reset = $('#reset');
        _this.submitBtn = $('#submitBtn');

        _this.isCorrectlyDropped = false;
        _this.droppedItemsCount = 0;
        _this.currentDropElemId = "";
        _this.correctAnswersCount = 0;
        _this.inCorrectAnswersCount = 0;

        _this.getJsonData();
        _this.addEvents();
    }

    this.getJsonData = function(){
        $.ajax({
            url : "assets/data/myjsondata.json",
            type : "GET",
            cache : false,
            success : _this.loadDatasSuccess,
            error : _this.onLoadError
        });
    }

    this.loadDatasSuccess = function(jsondatas){
        _this.jsonDatas = jsondatas.data;
        console.log("Json Data Is",_this.jsonDatas);

        _this.audioElem.attr('src', _this.jsonDatas.audio.audioPath + _this.jsonDatas.audio.actStartAudio);
        _this.audioElem[0].play();

        _this.loadDragDatas();
    }

    this.onLoadError = function(){
        console.log("Error on loading json data");
    }

    this.loadDragDatas = function(){
      
        for(let i=0; i<_this.jsonDatas.dragData.length; i++){
            $('#'+_this.jsonDatas.dragData[i].id).css({
                "background" : "url("+_this.jsonDatas.imagePath+_this.jsonDatas.dragData[i].bgImage+")",
            }).attr('key',_this.jsonDatas.dragData[i].key);
            $('#'+_this.jsonDatas.dragData[i].id).text(_this.jsonDatas.dragData[i].text);

            $('#clone_'+_this.jsonDatas.dragData[i].id).css({
                "background" : "url("+_this.jsonDatas.imagePath+_this.jsonDatas.dragData[i].bgImage1+")",
            }).attr('key',_this.jsonDatas.dragData[i].key);
            $('#clone_txt'+_this.jsonDatas.dragData[i].id).text(_this.jsonDatas.dragData[i].text);

            $("<span class='flag' id=cloneSpan_"+_this.jsonDatas.dragData[i].id+"></span>").appendTo('#clone_'+_this.jsonDatas.dragData[i].id);
        }

        for(let i=0; i<_this.jsonDatas.dropData.length; i++){
            $('#dropHolder'+_this.jsonDatas.dropData[i].id).attr('bay',_this.jsonDatas.dropData[i].bay);
        }
    }

    this.addEvents = function(){
        $('.dragItem').draggable({
            appendTo: "body",
            containment : $('body'),
            start: function(){
                _this.isCorrectlyDropped = false;
                _this.droppedItemsCount = 0;
                $(_this.submitBtn).css('pointer-events' , 'none');
            },
            drag: function(){
                $(this).css('z-index',1);
            },
            stop: function(){
                $(this).css('z-index',0);
                if(_this.isCorrectlyDropped){
                    console.log('Valid Drop');
                }else{
                    console.log('Invalid Drop');
                    _this.revert(this);
                }
            }
        });

        $('.dropItemHolder').droppable({
            drop: function(event,ui){
                _this.isCorrectlyDropped = true;
                _this.curDragElement = $(ui.draggable);
                _this.curDroppedElment = $(this);
                _this.appendElement();
                _this.isAllItemsDropped();
            }
        });

        _this.actCloseBtn.off("click").on("click",_this.closeActivity);
        _this.submitBtn.off("click").on("click",_this.validation);
        _this.reset.off("click").on("click",_this.resetActivity);
    }

    this.revert = function(curElem){
        $(curElem).css({
            "top" : "0",
            "left" : "0",
            "right" : "0",
            "bottom" : "0"
        });
    }

    this.appendElement = function(){
        $(_this.curDragElement).appendTo(_this.curDroppedElment[0]);
        _this.placeRandomly();	
    }

    this.isAllItemsDropped = function(){

        for(let i=0; i<_this.jsonDatas.dropData.length; i++){
            _this.droppedItemsCount = _this.droppedItemsCount + $('#dropHolder'+(i+1)).children().length;
        }

        if(_this.droppedItemsCount == 7){
            $(_this.submitBtn).css('pointer-events' , 'auto');
        }
    }
    
    this.placeRandomly = function(curElem){

        let id = $(_this.curDroppedElment[0]).attr('id'),
            destId = id.charAt(10);

        if(destId == 1){
            var randomNum = Math.floor(Math.random()*(700 - 630 + 1) + 610),
                randomNum1 = Math.floor(Math.random()*(400 - 390 + 1) + 390);

        }else if(destId == 2){
            var randomNum = Math.floor(Math.random()*(935 - 850 + 1) + 850),
                randomNum1 = Math.floor(Math.random()*(400 - 390 + 1) + 390);
        }else{
            var randomNum = Math.floor(Math.random()*(1200 - 1140 + 1) + 1140),
                randomNum1 = Math.floor(Math.random()*(400 - 390 + 1) + 390);
        }

        $(_this.curDragElement).css({
            "position" : "absolute",
            "top" : randomNum1,
            "left" : randomNum,
            "right" : "0",
        });
    }

    this.validation = function(){
        for(let i=0; i<_this.jsonDatas.dropData.length; i++){

            let currentbay =  $('#dropHolder'+(i+1)).attr('bay'),
                childrens = $('#dropHolder'+(i+1)).children();

            for(let j=0; j<$('#dropHolder'+(i+1)).children().length; j++){
                let currentkey = $(childrens[j]).attr('key'),
                    id = $(childrens[j]).attr('id');
               if( currentbay == currentkey ){
                    $('#cloneSpan_'+id).css({
                        "background" : "url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.correct+") no-repeat",
                        "opacity" : "1",
						"background-size" : "100% 100%"
                    });

                    _this.correctAnswersCount++;
               }else{
                $('#cloneSpan_'+id).css({
                    "background" : "url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.incorrect+") no-repeat",
                    "opacity" : "1",
					"background-size" : "100% 100%"
                });

                _this.inCorrectAnswersCount++;
               }
            }
        }

        if(_this.correctAnswersCount == 6 || _this.correctAnswersCount == 5){
            console.log("you almost correct");

            _this.audioElem.attr('src', _this.jsonDatas.audio.audioPath + _this.jsonDatas.audio.almostCorrect);
            _this.audioElem[0].play();
        }else if(_this.correctAnswersCount == 7){
            console.log("All correct");
            
            _this.audioElem.attr('src', _this.jsonDatas.audio.audioPath + _this.jsonDatas.audio.allCorrectAnswer);
            _this.audioElem[0].play();
        }else{
            console.log("Incorrect");

            _this.audioElem.attr('src', _this.jsonDatas.audio.audioPath + _this.jsonDatas.audio.incorrect);
            _this.audioElem[0].play();
        }

        _this.correctAnswersCount = 0;
    }

    this.closeActivity = function(){
        console.log("Close this activity");	
    }

    this.resetActivity = function(){
		for(let i=0; i<_this.jsonDatas.dragData.length; i++){
            $('#'+_this.jsonDatas.dragData[i].id).css({
                "position" : "relative",
                "top" : "0",
                "left" : "0",
                "right" : "0",
                "bottom" : "0"
            })
            $('#'+_this.jsonDatas.dragData[i].id).appendTo($('#dragHolder'+_this.jsonDatas.dragData[i].id));
		}

        $('.flag').css('opacity','0');
        $(_this.submitBtn).css('pointer-events','none');
        _this.correctAnswersCount = 0;
    }
}